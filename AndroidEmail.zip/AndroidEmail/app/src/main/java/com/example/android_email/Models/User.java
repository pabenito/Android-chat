package com.example.android_email.Models;

import java.io.Serializable;

public class User implements Serializable {
    public String name;

}
