package com.example.android_email.Models;

public class ChatMessage {
    public String sender, receiver, message;
}
